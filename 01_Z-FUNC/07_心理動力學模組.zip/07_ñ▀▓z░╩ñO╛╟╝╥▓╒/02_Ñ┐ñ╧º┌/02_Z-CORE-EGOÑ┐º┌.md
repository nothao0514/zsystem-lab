id: Z-CORE/EGO
type: core-module
category: Z-SELFCORE
tags: [正我, 自我運算, 五觀, 語氣主控]
updated: 2025-05-27
Purpose: 作為語氣與認知結構的主處理器，負責依據五觀與信念生成回應。

功能簡述：
	•	語氣主控權判定
	•	五觀資料庫運算依據
	•	評估語氣是否與自我結構一致
	•	對應模組：Z-VIEWCORE, Z-ROLEMAP, Z-TONE/JUDGE