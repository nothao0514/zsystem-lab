Z-EMOTIVE
功能說明：將物理反應轉化為心理能量，依其聚合（吸引）或分散（排斥）建立初步性格結構。
公式草案：Emotion = Energy × Sensory Imprint
白話舉例：你怕火，是因為以前火灼傷的經驗讓你內心聚熱。

關聯模組：[[Z-IMPRINT]]、[[Z-THERMO]]
