Z-PHYSICS
功能說明：描述外部事件透過五感刺激造成即時物理反應，為整個系統的基底能量輸入點。

公式草案：Reaction = Stimulus × Time-direction
運用舉例：手被燙到反射縮回；聽到怒罵產生心跳加速。
關聯模組：[[Z-SENSE]]、[[Z-FIELD]]
